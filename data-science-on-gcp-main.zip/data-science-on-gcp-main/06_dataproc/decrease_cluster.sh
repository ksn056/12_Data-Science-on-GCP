gcloud dataproc clusters update ch6cluster\
   --num-secondary-workers=0 --num-workers=2 --region=us-central1
