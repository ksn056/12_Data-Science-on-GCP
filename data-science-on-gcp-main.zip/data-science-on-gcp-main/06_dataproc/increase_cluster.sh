gcloud dataproc clusters update ch6cluster\
   --num-secondary-workers=3 --num-workers=4 --region=us-central1
